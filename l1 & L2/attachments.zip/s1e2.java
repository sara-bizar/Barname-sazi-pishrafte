package s1e2farkoosh;

import java.util.Scanner;

public class s1e2 {
    public static void main(String[] args) {
        int n;
        Scanner input = new Scanner(System.in);
        System.out.println("enter arraysize:");
        n=input.nextInt();
        int[] numbers= new int[n];
        System.out.println("enter array numbers:");
        for (int i = 0; i < n; i++) {
            numbers[i]=input.nextInt();
        }
        int maxnum = numbers[0];
        for (int j = 0; j <n ; j++) {
            if(maxnum<numbers[j]){
                maxnum=numbers[j];
            }
        }
        System.out.println("the maximum number is : "+ maxnum);
    }
}

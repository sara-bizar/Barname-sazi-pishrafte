package s1_e3farkoosh;

import java.util.Scanner;

public class s1_e3 {
    public static void main(String[] args) {
        char operator;
        int number1,number2,temp;
        Scanner input = new Scanner(System.in);
        System.out.print("enter two numbers:");
        number1=input.nextInt();
        number2=input.nextInt();
        System.out.println("enter the operator you want: ");
        operator=input.next().charAt(0);
        if(number1<number2){
           temp=number1;
           number1=number2;
           number2=temp;
        }
;        switch(operator){
            case'+':
                System.out.println(number1 +number2);
                break;
            case'*':
                System.out.println(number1*number2);
                break;
            case'/':
                System.out.println(number1/number2);
                break;
            case'-':
                System.out.println(number1-number2);
                break;
            default:
                System.out.println("operater ineligible");
        }
    }
}

package s1k1farkoosh;

import java.util.Scanner;

public class class_exercises1 {
    static int searchh (int innumber, int[] numbers) {
        int repetition = 0;
        for (int i = 0; i < 5; i++) {
            if (numbers[i] == innumber) {
                repetition++;
            }

        }
        return repetition;
    }
    public static void main(String[] args) {
        System.out.println("enter a array of numbers : ");
        Scanner input = new Scanner(System.in);
        int[] numbers= new int[5];
        for (int i = 0; i <5 ; i++) {
            numbers[i]=input.nextInt();
        }
        System.out.println("enter the number you want it to be searched:");
        int innumber=input.nextInt();
        if(searchh(innumber,numbers)>0){
            System.out.println("there is a number like that");
            System.out.println("which is reapeted "+searchh(innumber,numbers)+"times .");
        }
        else {
            System.out.println("number not found !");
        }

    }

}

package exercise2l1;

import java.util.Scanner;

public class E2 {
    public static void main(String[] args) {

        Student student1 = new Student();
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter student marks ratio then the mark (5 marks in total):");
       String string;
        for (int i = 0; i <5 ; i++) {
            string=scanner.nextLine();
            student1.marksRatio[i]= Integer.parseInt(string) ;
            string=scanner.nextLine();
            student1.studentMarks[i]= Float.parseFloat(string);
        }
        System.out.println("Student average = "+ student1.average());
        if(student1.averageEvaluate())
        System.out.println("normal ");
        else
            System.out.println("mashroot");

    }


}


class Student{
    int studentNo;
    float average;
    float[] studentMarks= new float[5];
    int[]  marksRatio= new int[5];

    float average (){
        float averageface=0;
        int averageDenominator=0;

        for (int i = 0; i < 5; i++) {

            averageDenominator+=marksRatio[i];
            averageface+=studentMarks[i]*marksRatio[i];
        }
        average = averageface/averageDenominator;
        return average;
    }
    boolean averageEvaluate (){
        if(average>12)
            return true;
        else
            return false;
    }
}


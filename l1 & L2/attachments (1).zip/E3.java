package exercise3l1;

import java.util.Scanner;

public class E3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String string;
        Equation e1 = new Equation();
        Equation e2 = new Equation();
        System.out.println("enter the first equation parameters a,b,c like in(ax + by = c) : ");//entering first equation coefficient
        string=scanner.nextLine();
        e1.a=Double.parseDouble(string);
        string=scanner.nextLine();
        e1.b=Double.parseDouble(string);
        string=scanner.nextLine();
        e1.c=Double.parseDouble(string);

        System.out.println("enter the second equation parameters a,b,c like in(ax + by = c) : ");//entering second equation coefficient
        string=scanner.nextLine();
        e2.a=Double.parseDouble(string);
        string=scanner.nextLine();
        e2.b=Double.parseDouble(string);
        string=scanner.nextLine();
        e2.c=Double.parseDouble(string);

        System.out.println(e1.equationEvaluate(e2));//number of answers
        if(e1.equationEvaluate(e2)=="one answer"){
            System.out.println("x= "+e1.equationAnswer(e2).x);
            System.out.println("y= "+e1.equationAnswer(e2).y);
        }





    }
}
class Equation {
    double a;
    double b;
    double c;
    boolean existAnswer=false;
    String equationEvaluate (Equation secondEquation){
        if(a/secondEquation.a == b/secondEquation.b && a/secondEquation.a!=c/ secondEquation.c ){
            return "no answer";
        }
        else if(a/secondEquation.a == b/secondEquation.b && a/secondEquation.a==c/ secondEquation.c )
            return "infinite answers";
        else {
            existAnswer=true;
            return "one answer";
        }
    }
    point equationAnswer (Equation secondEquation) {
        point answer = new point();
        if(existAnswer){
        answer.x=((c* secondEquation.b)-(b*secondEquation.c))/((a*secondEquation.b)-(b* secondEquation.a));
        answer.y=((a*secondEquation.c)-(c* secondEquation.a))/((a*secondEquation.b)-(b* secondEquation.a));

        }
        return answer;

}}

class point {//point class to output cartesian answers
    double x;
    double y;
    }


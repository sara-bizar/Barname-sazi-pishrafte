package clexercisel1;

import java.util.Date;
import java.util.Scanner;

public class LibraryClasExerciseL2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] fillerbook={"no book","no book","no book","no book"};
        libraryMember person1=new libraryMember(fillerbook);
        String decider;
        String bookName;
        System.out.println("do you want to borrow or give back the book?(enter b for borrow and g for giveback) : ");
        decider = scanner.nextLine();

        if(decider.equals("g")){
            System.out.println("enter the name of the book : ");
            bookName=scanner.nextLine();
            person1.givingBack(bookName);
            System.out.println("ok book received");
        }
        System.out.println("is there any book you want to borrow ?(yes/no) ");
        decider=scanner.nextLine();

        if(decider.equals("yes")){
            System.out.println("enter the book' s name :");
            bookName=scanner.nextLine();
            person1.borrowing(bookName);
            System.out.println("ok you're borrowed book's name registered.");
        }
    }

}
class libraryMember{
    boolean[] borrowed = {false,false,false,false};
    String[] borrowedNames = new String[4];
    libraryMember( String[] BNprime){
        for (int i = 0; i < 4; i++) {
            borrowedNames[i] = BNprime[i];
        }
    }



    void borrowing (String bookName){
        boolean result=false;
        for (int i = 0; i < 4; i++) {
            if (!borrowed[i]){
                borrowedNames[i]=bookName;
                result = true;
                break;
                }
            if (!result && i==4)
                System.out.println("no free slot");
                }
            }

    void givingBack (String givenBackBook){
        for (int i = 0; i <4 ; i++) {
            if(borrowedNames[i].equals(givenBackBook)){
                borrowedNames[i]="no book";
                borrowed[i]=false;
                break;
            }
        }
    }


}

package exercise1s2;

import java.sql.SQLOutput;
import java.util.Scanner;


public class E1 {

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        
        Square first = new Square();
        System.out.println("enter the side of the square:");
        String stringg;
        stringg = input.nextLine();
        first.side=Double.parseDouble(stringg);
        System.out.println("square's area"+first.area());
        System.out.println("square's perimeter :"+first.perimeter());//square class testing ends
        
        Rectangular sample1 = new Rectangular();
        System.out.println("enter width and length of a rectangular: ");
        stringg = input.nextLine();
        sample1.width=Double.parseDouble(stringg);
        stringg = input.nextLine();
        sample1.length=Double.parseDouble(stringg);
        System.out.println("rectangular's area : "+sample1.area());
        System.out.println("rectangular's perimeter : "+sample1.perimeter());//rectangular class ends
    }
}

class  Rectangular{
    
    double length;
    double width;
    
    double area(){
        double area ;
            area = width*length;
            return area;
        }
        
        double perimeter(){
        double premitere;
        premitere=(width+length)*2;
        return premitere;
        }

        
    }

class Square {
    double side;

    double perimeter () {
        double perimeter=0;
        perimeter=side*4;
        return perimeter;
    }

    double area () {
        double area=0;
        area=side*side;
        return area;
    }

}

